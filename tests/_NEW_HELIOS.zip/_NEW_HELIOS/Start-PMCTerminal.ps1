# FILE: Start-PMCTerminal.ps1
# PURPOSE: Main entry point for the PMC Terminal v5 application.
#          Orchestrates module loading, service initialization, and application startup,
#          adhering to the PowerShell-First architectural principles.

# Set strict mode for better error handling
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Get the directory where this script is located
$script:BasePath = Split-Path -Parent $MyInvocation.MyCommand.Path

#region --- Helper Functions ---

function Load-PMCTerminalModules {
    param([bool]$Silent = $false)
    
    Invoke-WithErrorHandling -Component "ModuleLoader" -Context @{ Operation = "Load-PMCTerminalModules" } -ScriptBlock {
        if (-not $Silent) { Write-Host "Initializing PMC Terminal v5..." -ForegroundColor Cyan }
        $loadedModules = @()
        
        # Corrected module loading order to respect dependencies.
        # UI primitives are loaded before systems that use them.
        $script:ModulesToLoad = @(
            # Core utilities first
            @{ Name = "theme-support"; Path = "modules\theme-support.psm1"; Required = $true },
            @{ Name = "focus-manager"; Path = "modules\focus-manager.psm1"; Required = $true },
            @{ Name = "event-system"; Path = "modules\event-system.psm1"; Required = $true },
            # Core engine next, it provides primitives for components
            @{ Name = "tui-engine"; Path = "modules\tui-engine.psm1"; Required = $true },
            # UI library that depends on the engine and theme
            @{ Name = "helios-panels"; Path = "ui\helios-panels.psm1"; Required = $true },
            @{ Name = "helios-components"; Path = "ui\helios-components.psm1"; Required = $true },
            # High-level systems that use the UI library
            @{ Name = "dialog-system"; Path = "modules\dialog-system.psm1"; Required = $true },
            # Application services last
            @{ Name = "task-service"; Path = "services\task-service.psm1"; Required = $true },
            @{ Name = "keybindings"; Path = "services\keybindings.psm1"; Required = $true },
            @{ Name = "navigation"; Path = "services\navigation.psm1"; Required = $true }
        )

        foreach ($module in $script:ModulesToLoad) {
            $modulePath = Join-Path $script:BasePath $module.Path
            
            try {
                if (Test-Path $modulePath) {
                    if (-not $Silent) { Write-Host "  Loading $($module.Name)..." -ForegroundColor Gray }
                    Import-Module $modulePath -Force -Global -ErrorAction Stop
                    $loadedModules += $module.Name
                } elseif ($module.Required) { 
                    throw "Required module not found: $($module.Name) at $modulePath"
                }
            } catch {
                throw "Failed to load module $($module.Name): $($_.Exception.Message)"
            }
        }
        
        if (-not $Silent) { Write-Host "Loaded $($loadedModules.Count) core modules successfully." -ForegroundColor Green }
        return $loadedModules
    }
}

function Initialize-PMCTerminalServices {
    param([bool]$Silent = $false)
    
    Invoke-WithErrorHandling -Component "ServiceInitializer" -Context @{ Operation = "Initialize-PMCTerminalServices" } -ScriptBlock {
        if (-not $Silent) { Write-Host "Initializing services..." -ForegroundColor Cyan }
        
        $services = [PSCustomObject]@{}
        
        $services | Add-Member -MemberType NoteProperty -Name Task -Value (Initialize-TaskService)
        $services | Add-Member -MemberType NoteProperty -Name Keybindings -Value (Initialize-KeybindingService)
        $services | Add-Member -MemberType NoteProperty -Name Navigation -Value (Initialize-NavigationService)
        
        if (-not $services.Task -or -not $services.Keybindings -or -not $services.Navigation) {
            throw "One or more core services failed to initialize."
        }
        
        if (-not $Silent) { Write-Host "Services initialized successfully." -ForegroundColor Green }
        return $services
    }
}

function Register-PMCTerminalScreens {
    param(
        [PSCustomObject]$Services,
        [bool]$Silent = $false
    )
    
    Invoke-WithErrorHandling -Component "ScreenRegistration" -Context @{ Operation = "Register-PMCTerminalScreens" } -ScriptBlock {
        if (-not $Services.Navigation) { throw "Navigation service is null, cannot register screens." }

        if (-not $Silent) { Write-Host "Loading screens and registering routes..." -ForegroundColor Cyan }
        
        $script:ScreenModules = @( "dashboard-screen", "task-screen" )
        $registeredScreens = @()
        
        foreach ($screenName in $script:ScreenModules) {
            $screenPath = Join-Path $script:BasePath "screens\$screenName.psm1"
            if (Test-Path $screenPath) {
                if (-not $Silent) { Write-Host "  Loading $($screenName)..." -ForegroundColor Gray }
                Import-Module $screenPath -Force -Global
                
                # Fix: Strip '-screen' suffix before processing to avoid double 'Screen' in function name
                $baseScreenName = $screenName -replace '-screen$', ''
                $factoryFunctionName = "Get-Helios" + (($baseScreenName.Substring(0,1).ToUpper() + $baseScreenName.Substring(1)) + "Screen")
                
                if (Get-Command -Name $factoryFunctionName -ErrorAction SilentlyContinue) {
                    $path = "/$($screenName.Replace('-screen',''))"
                    
                    # FIXED: Create a factory scriptblock that embeds the function name directly
                    # This avoids closure issues entirely by using string substitution
                    $factoryScriptText = @"
                        param([PSCustomObject]`$Services)
                        Invoke-WithErrorHandling -Component "ScreenFactory" -Context @{ Function = "$factoryFunctionName" } -ScriptBlock {
                            # Call the screen factory function directly by name
                            return $factoryFunctionName -Services `$Services
                        }
"@
                    $factoryScript = [ScriptBlock]::Create($factoryScriptText)
                    
                    $Services.Navigation.RegisterRoute($path, $factoryScript)
                    $registeredScreens += $screenName
                } else {
                    Write-Log -Level Warning -Message "Expected screen factory '$factoryFunctionName' not found for module '$screenName'."
                }
            } else { 
                Write-Log -Level Warning -Message "Screen module not found: $screenName at $screenPath."
            }
        }
        
        if (-not $Silent) { Write-Host "Registered $($registeredScreens.Count) screens successfully." -ForegroundColor Green }
        return $registeredScreens
    }
}

#endregion

#region --- Main Application Entry Point ---

function Start-PMCTerminal {
    param([bool]$Silent = $false)
    
    try {
        Invoke-WithErrorHandling -Component "Start-PMCTerminal" -Context @{ SilentMode = $Silent } -ScriptBlock {
            Write-Log -Level Info -Message "PMC Terminal v5 startup initiated."
            
            $minWidth = 80; $minHeight = 24
            if ($Host.UI.RawUI) {
                $currentWidth = $Host.UI.RawUI.WindowSize.Width
                $currentHeight = $Host.UI.RawUI.WindowSize.Height
                if ($currentWidth -lt $minWidth -or $currentHeight -lt $minHeight) {
                    Write-Host "Console window too small! Minimum required: ${minWidth}x${minHeight}. Please resize and restart." -ForegroundColor Red
                    exit 1
                }
            }

            Load-PMCTerminalModules -Silent:$Silent
            Initialize-TuiEngine
            $global:Services = Initialize-PMCTerminalServices -Silent:$Silent
            # FIX: Initialize the Focus Manager so it can subscribe to events.
            Initialize-FocusManager
            Register-PMCTerminalScreens -Services $global:Services -Silent:$Silent
            
            if (-not $Silent) { Write-Host "`nStarting application..." -ForegroundColor Green }
            
            $startPath = "/dashboard"
            if ($global:Services.Navigation.IsValidRoute($startPath)) {
                $global:Services.Navigation.GoTo($startPath, $global:Services)
            } else {
                throw "Default startup route '$startPath' is not valid."
            }
            
            Start-TuiLoop
        }
        
        Write-Log -Level Info -Message "PMC Terminal exited gracefully."
        return $true

    } catch {
        $Exception = $_.Exception
        $DetailedError = if ($Exception -is [Helios.HeliosException]) { $Exception.DetailedContext } else { $null }

        Write-Host "`n=== CRITICAL FAILURE ===" -ForegroundColor Red
        Write-Host "Fatal error occurred during PMC Terminal startup." -ForegroundColor Red
        Write-Host "Error: $($Exception.Message)" -ForegroundColor Red
        
        if ($DetailedError) {
            $component = $DetailedError.AdditionalContext.Component ?? 'Unknown'
            Write-Host "Component: $component" -ForegroundColor Yellow
            Write-Host "Location: $($DetailedError.ScriptName):$($DetailedError.LineNumber)" -ForegroundColor Gray
        }
        
        Write-Host "`nCheck the log file for more details: $(Get-LogPath)" -ForegroundColor Cyan
        Write-Host "=== END CRITICAL FAILURE ===" -ForegroundColor Red
        
        return $false
    }
}

#endregion

#region --- Main Execution Block ---

$script:Silent = $args -contains "-silent" -or $args -contains "-s"

try {
    # CRITICAL: Pre-load essential modules (exceptions, logger) BEFORE anything else.
    # This ensures Invoke-WithErrorHandling and Write-Log are available immediately.
    $exceptionsModulePath = Join-Path $script:BasePath "modules\exceptions.psm1"
    $loggerModulePath = Join-Path $script:BasePath "modules\logger.psm1"
    
    if (-not (Test-Path $exceptionsModulePath)) { throw "CRITICAL FAILURE: The core exception handling module is missing at '$exceptionsModulePath'. Cannot continue." }
    if (-not (Test-Path $loggerModulePath)) { throw "CRITICAL FAILURE: The core logger module is missing at '$loggerModulePath'. Cannot continue." }
    
    Import-Module $exceptionsModulePath -Force -Global
    Import-Module $loggerModulePath -Force -Global

    # Initialize logger as early as possible
    Initialize-Logger
    
    # Provide immediate feedback to the user
    if (-not $script:Silent) {
        Write-Host "PMC Terminal v5 - Initializing..." -ForegroundColor Cyan
        Write-Host "Log files written to: $(Get-LogPath)" -ForegroundColor Green
        Write-Host ""
    }
    
    # Start the terminal application
    $appSuccess = Start-PMCTerminal -Silent:$script:Silent
    
    if (-not $appSuccess) {
        # If Start-PMCTerminal returned $false due to a handled error, exit with a non-zero code.
        exit 1
    }

} catch {
    # This is the ultimate fallback error handler if Invoke-WithErrorHandling or pre-loading itself fails.
    Write-Host "`n!!! ULTIMATE FALLBACK ERROR HANDLER !!!" -ForegroundColor Red
    Write-Host "An unhandled critical error occurred during PMC Terminal startup." -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Script stack trace:" -ForegroundColor Yellow
    Write-Host $_.ScriptStackTrace -ForegroundColor Gray
    exit 1 # Exit with error code
    
} finally {
    # Final cleanup before exiting. This block always runs.
    # Only perform cleanup that is safe even after a crash.
    if (Get-Command -Name "Cleanup-TuiEngine" -ErrorAction SilentlyContinue) { 
        if (-not $script:Silent) { Write-Host "`nShutting down TUI Engine..." -ForegroundColor Gray }
        Cleanup-TuiEngine
    }

    if (-not $script:Silent) { Write-Host "Goodbye!" -ForegroundColor Green }
    if (Get-Command -Name "Write-Log" -ErrorAction SilentlyContinue) {
        Write-Log -Level Info -Message "PMC Terminal application exit complete."
    }
    
    # Let the exit code from the try/catch blocks control the process.
}

#endregion